# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 12:30:37 2024

@author: Zhuangji.Wang
"""

import pandas as pd
import numpy as np

baseDir = 'D:\\Ryesim\\CALIBRATION_EXAMPLE\\'
df=pd.read_csv(baseDir+'BARC2010'+'\\'+'N_52'+'\\'+'BARC2010'+'.g01')
Rue_df=pd.DataFrame(df,columns=['RUE            '])
Rue_df['RUE            ']=Rue_df['RUE            '].fillna(0)

df=pd.read_table('D:\\Ryesim\\CALIBRATION_EXAMPLE\\BARC2010\\'+'BARC'+'.wea')
