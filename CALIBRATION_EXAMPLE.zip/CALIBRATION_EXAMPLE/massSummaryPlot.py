# -*- coding: utf-8 -*-
"""
Created on Sat Dec 23 14:22:05 2023

@author: Zhuangji.Wang
"""

# biomass/N mass Summary
import pandas as pd
import numpy as np

baseDir = 'D:\\Ryesim\\CALIBRATION_EXAMPLE\\'
siteList=['BARC2009','BARC2010','BARC2011','LARC2011','CRSK2011','PRSS2011']
treatmentList_BARC2009=['N_00','N_10','N_20','N_40','N_60']
treatmentList_other=['N_00','N_01','N_02','N_10','N_11','N_12','N_20','N_21','N_22','N_30','N_31','N_32','N_50','N_51','N_52']

# shootbiomassBarc2009=[]
# rootbiomassBarc2009=[]
# nitrogenBarc2009=[]
# for trt in treatmentList_BARC2009:
#     TargetDir=baseDir+siteList[0]+'\\'+trt+'\\'+siteList[0]+'.g01'
#     df=pd.read_csv(TargetDir)
#     df.set_index(['date','       time'], inplace=True)
    
#     shoot_biomass=df.loc[('03/25/2010',0)]['  ShootMass']*df.loc[('03/25/2010',0)]['PltLivingFrac']*500.0
#     root_biomass=df.loc[('03/25/2010',0)]['   RootMass']*df.loc[('03/25/2010',0)]['PltLivingFrac']*500.0
#     nitrogen_mass=df.loc[('03/25/2010',0)]['     NitroMass']*df.loc[('03/25/2010',0)]['PltLivingFrac']*500.0
#     shootbiomassBarc2009.append(shoot_biomass)
#     rootbiomassBarc2009.append(root_biomass)
#     nitrogenBarc2009.append(nitrogen_mass)
    
#     shoot_biomass=df.loc[('04/20/2010',0)]['  ShootMass']*df.loc[('04/20/2010',0)]['PltLivingFrac']*500.0
#     root_biomass=df.loc[('04/20/2010',0)]['   RootMass']*df.loc[('04/20/2010',0)]['PltLivingFrac']*500.0
#     nitrogen_mass=df.loc[('04/20/2010',0)]['     NitroMass']*df.loc[('04/20/2010',0)]['PltLivingFrac']*500.0
#     shootbiomassBarc2009.append(shoot_biomass)
#     rootbiomassBarc2009.append(root_biomass)
#     nitrogenBarc2009.append(nitrogen_mass)
    
#     shoot_biomass=df.loc[('05/11/2010',0)]['  ShootMass']*df.loc[('05/11/2010',0)]['PltLivingFrac']*500.0
#     root_biomass=df.loc[('05/11/2010',0)]['   RootMass']*df.loc[('05/11/2010',0)]['PltLivingFrac']*500.0
#     nitrogen_mass=df.loc[('05/11/2010',0)]['     NitroMass']*df.loc[('05/11/2010',0)]['PltLivingFrac']*500.0
#     shootbiomassBarc2009.append(shoot_biomass)
#     rootbiomassBarc2009.append(root_biomass)
#     nitrogenBarc2009.append(nitrogen_mass)

##################################################################
shootbiomassBarc2010=[]
rootbiomassBarc2010=[]
nitrogenBarc2010=[]
leafareaBARC2010=[]
for trt in treatmentList_other:
    TargetDir=baseDir+siteList[1]+'\\'+trt+'\\'+siteList[1]+'.g01'
    df=pd.read_csv(TargetDir)
    df.set_index(['date','       time'], inplace=True)
    
    shoot_biomass_1=0.0
    shoot_biomass_2=0.0
    shoot_biomass_3=0.0
    
    root_biomass_1=0.0
    root_biomass_2=0.0
    root_biomass_3=0.0
    
    nitrogen_mass_1=0.0
    nitrogen_mass_2=0.0
    nitrogen_mass_3=0.0
    
    leaf_area=0.0
    green_leaf_area=0.0
    
    for iii in range(24):
        
        shoot_biomass_1=shoot_biomass_1+df.loc[('03/02/2011',iii)]['  ShootMass']*df.loc[('03/02/2011',iii)]['PltLivingFrac']*500.0
        shoot_biomass_2=shoot_biomass_2+df.loc[('03/28/2011',iii)]['  ShootMass']*df.loc[('03/28/2011',iii)]['PltLivingFrac']*500.0
        shoot_biomass_3=shoot_biomass_3+df.loc[('05/01/2011',iii)]['  ShootMass']*df.loc[('05/01/2011',iii)]['PltLivingFrac']*500.0
        
        root_biomass_1=root_biomass_1+df.loc[('03/02/2011',iii)]['   RootMass']*df.loc[('03/02/2011',iii)]['PltLivingFrac']*500.0
        root_biomass_2=root_biomass_2+df.loc[('03/28/2011',iii)]['   RootMass']*df.loc[('03/28/2011',iii)]['PltLivingFrac']*500.0
        root_biomass_3=root_biomass_3+df.loc[('05/01/2011',iii)]['   RootMass']*df.loc[('05/01/2011',iii)]['PltLivingFrac']*500.0
        
        nitrogen_mass_1=nitrogen_mass_1+df.loc[('03/02/2011',iii)]['     NitroMass']*df.loc[('03/02/2011',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_2=nitrogen_mass_2+df.loc[('03/28/2011',iii)]['     NitroMass']*df.loc[('03/28/2011',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_3=nitrogen_mass_3+df.loc[('05/01/2011',iii)]['     NitroMass']*df.loc[('05/01/2011',iii)]['PltLivingFrac']*500.0
        
        leaf_area=leaf_area+df.loc[('05/01/2011',iii)]['   LeaveArea']*df.loc[('05/01/2011',iii)]['PltLivingFrac']*500.0/10000
        green_leaf_area=green_leaf_area+df.loc[('05/01/2011',iii)][' GreenLfArea']*df.loc[('05/01/2011',iii)]['PltLivingFrac']*500.0/10000
    
    shoot_biomass_1=shoot_biomass_1/24.0
    shoot_biomass_2=shoot_biomass_2/24.0
    shoot_biomass_3=shoot_biomass_3/24.0
    
    root_biomass_1=root_biomass_1/24.0
    root_biomass_2=root_biomass_2/24.0
    root_biomass_3=root_biomass_3/24.0
    
    nitrogen_mass_1=nitrogen_mass_1/24.0
    nitrogen_mass_2=nitrogen_mass_2/24.0
    nitrogen_mass_3=nitrogen_mass_3/24.0
    
    leaf_area=leaf_area/24.0
    green_leaf_area=green_leaf_area/24.0

    shootbiomassBarc2010.append(shoot_biomass_1)
    shootbiomassBarc2010.append(shoot_biomass_2)
    shootbiomassBarc2010.append(shoot_biomass_3)
    
    rootbiomassBarc2010.append(root_biomass_1)
    rootbiomassBarc2010.append(root_biomass_2)
    rootbiomassBarc2010.append(root_biomass_3)
    
    nitrogenBarc2010.append(nitrogen_mass_1)
    nitrogenBarc2010.append(nitrogen_mass_2)
    nitrogenBarc2010.append(nitrogen_mass_3)
    
    leafareaBARC2010.append(leaf_area)
    leafareaBARC2010.append(green_leaf_area)
    
BARC2010ShootMassReshape=np.reshape(shootbiomassBarc2010, (15,3))
BARC2010RootMassReshape=np.reshape(rootbiomassBarc2010, (15,3))
BARC2010NitrogenMassReshape=np.reshape(nitrogenBarc2010, (15,3))
BARC2010LeafAreaReshape=np.reshape(leafareaBARC2010, (15,2))

BARC2010ALL=np.concatenate((BARC2010ShootMassReshape, BARC2010RootMassReshape, BARC2010NitrogenMassReshape), axis=0)
    
##################################################################
shootbiomassBarc2011=[]
rootbiomassBarc2011=[]
nitrogenBarc2011=[]
leafareaBARC2011=[]
for trt in treatmentList_other:
    TargetDir=baseDir+siteList[2]+'\\'+trt+'\\'+siteList[2]+'.g01'
    df=pd.read_csv(TargetDir)
    df.set_index(['date','       time'], inplace=True)
    
    shoot_biomass_1=0.0
    shoot_biomass_2=0.0
    shoot_biomass_3=0.0
    
    root_biomass_1=0.0
    root_biomass_2=0.0
    root_biomass_3=0.0
    
    nitrogen_mass_1=0.0
    nitrogen_mass_2=0.0
    nitrogen_mass_3=0.0
    
    leaf_area=0.0
    green_leaf_area=0.0
    
    for iii in range(24):
        
        shoot_biomass_1=shoot_biomass_1+df.loc[('03/01/2012',iii)]['  ShootMass']*df.loc[('03/01/2012',iii)]['PltLivingFrac']*500.0
        shoot_biomass_2=shoot_biomass_2+df.loc[('03/22/2012',iii)]['  ShootMass']*df.loc[('03/22/2012',iii)]['PltLivingFrac']*500.0
        shoot_biomass_3=shoot_biomass_3+df.loc[('04/19/2012',iii)]['  ShootMass']*df.loc[('04/19/2012',iii)]['PltLivingFrac']*500.0
        
        root_biomass_1=root_biomass_1+df.loc[('03/01/2012',iii)]['   RootMass']*df.loc[('03/01/2012',iii)]['PltLivingFrac']*500.0
        root_biomass_2=root_biomass_2+df.loc[('03/22/2012',iii)]['   RootMass']*df.loc[('03/22/2012',iii)]['PltLivingFrac']*500.0
        root_biomass_3=root_biomass_3+df.loc[('04/19/2012',iii)]['   RootMass']*df.loc[('04/19/2012',iii)]['PltLivingFrac']*500.0
        
        nitrogen_mass_1=nitrogen_mass_1+df.loc[('03/01/2012',iii)]['     NitroMass']*df.loc[('03/01/2012',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_2=nitrogen_mass_2+df.loc[('03/22/2012',iii)]['     NitroMass']*df.loc[('03/22/2012',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_3=nitrogen_mass_3+df.loc[('04/19/2012',iii)]['     NitroMass']*df.loc[('04/19/2012',iii)]['PltLivingFrac']*500.0
        
        leaf_area=leaf_area+df.loc[('04/19/2012',iii)]['   LeaveArea']*df.loc[('04/19/2012',iii)]['PltLivingFrac']*500.0/10000
        green_leaf_area=green_leaf_area+df.loc[('04/19/2012',iii)][' GreenLfArea']*df.loc[('04/19/2012',iii)]['PltLivingFrac']*500.0/10000
    
    shoot_biomass_1=shoot_biomass_1/24.0
    shoot_biomass_2=shoot_biomass_2/24.0
    shoot_biomass_3=shoot_biomass_3/24.0
    
    root_biomass_1=root_biomass_1/24.0
    root_biomass_2=root_biomass_2/24.0
    root_biomass_3=root_biomass_3/24.0
    
    nitrogen_mass_1=nitrogen_mass_1/24.0
    nitrogen_mass_2=nitrogen_mass_2/24.0
    nitrogen_mass_3=nitrogen_mass_3/24.0
    
    leaf_area=leaf_area/24.0
    green_leaf_area=green_leaf_area/24.0
    
    shootbiomassBarc2011.append(shoot_biomass_1)
    shootbiomassBarc2011.append(shoot_biomass_2)
    shootbiomassBarc2011.append(shoot_biomass_3)
    
    rootbiomassBarc2011.append(root_biomass_1)
    rootbiomassBarc2011.append(root_biomass_2)
    rootbiomassBarc2011.append(root_biomass_3)
    
    nitrogenBarc2011.append(nitrogen_mass_1)
    nitrogenBarc2011.append(nitrogen_mass_2)
    nitrogenBarc2011.append(nitrogen_mass_3)
    
    leafareaBARC2011.append(leaf_area)
    leafareaBARC2011.append(green_leaf_area)
    
BARC2011ShootMassReshape=np.reshape(shootbiomassBarc2011, (15,3))
BARC2011RootMassReshape=np.reshape(rootbiomassBarc2011, (15,3))
BARC2011NitrogenMassReshape=np.reshape(nitrogenBarc2011, (15,3))
BARC2011LeafAreaReshape=np.reshape(leafareaBARC2011, (15,2))

BARC2011ALL=np.concatenate((BARC2011ShootMassReshape, BARC2011RootMassReshape, BARC2011NitrogenMassReshape), axis=0)

##################################################################
shootbiomassLarc2011=[]
rootbiomassLarc2011=[]
nitrogenLarc2011=[]
leafareaLARC2011=[]
for trt in treatmentList_other:
    TargetDir=baseDir+siteList[3]+'\\'+trt+'\\'+siteList[3]+'.g01'
    df=pd.read_csv(TargetDir)
    df.set_index(['date','       time'], inplace=True)
    
    shoot_biomass_1=0.0
    shoot_biomass_2=0.0
    shoot_biomass_3=0.0
    
    root_biomass_1=0.0
    root_biomass_2=0.0
    root_biomass_3=0.0
    
    nitrogen_mass_1=0.0
    nitrogen_mass_2=0.0
    nitrogen_mass_3=0.0
    
    leaf_area=0.0
    green_leaf_area=0.0
    
    for iii in range(24):
        
        shoot_biomass_1=shoot_biomass_1+df.loc[('03/12/2012',iii)]['  ShootMass']*df.loc[('03/12/2012',iii)]['PltLivingFrac']*500.0
        shoot_biomass_2=shoot_biomass_2+df.loc[('04/03/2012',iii)]['  ShootMass']*df.loc[('04/03/2012',iii)]['PltLivingFrac']*500.0
        shoot_biomass_3=shoot_biomass_3+df.loc[('05/09/2012',iii)]['  ShootMass']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0
        
        root_biomass_1=root_biomass_1+df.loc[('03/12/2012',iii)]['   RootMass']*df.loc[('03/12/2012',iii)]['PltLivingFrac']*500.0
        root_biomass_2=root_biomass_2+df.loc[('04/03/2012',iii)]['   RootMass']*df.loc[('04/03/2012',iii)]['PltLivingFrac']*500.0
        root_biomass_3=root_biomass_3+df.loc[('05/09/2012',iii)]['   RootMass']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0
        
        nitrogen_mass_1=nitrogen_mass_1+df.loc[('03/12/2012',iii)]['     NitroMass']*df.loc[('03/12/2012',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_2=nitrogen_mass_2+df.loc[('04/03/2012',iii)]['     NitroMass']*df.loc[('04/03/2012',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_3=nitrogen_mass_3+df.loc[('05/09/2012',iii)]['     NitroMass']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0
        
        leaf_area=leaf_area+df.loc[('05/09/2012',iii)]['   LeaveArea']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0/10000
        green_leaf_area=green_leaf_area+df.loc[('05/09/2012',iii)][' GreenLfArea']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0/10000
    
    shoot_biomass_1=shoot_biomass_1/24.0
    shoot_biomass_2=shoot_biomass_2/24.0
    shoot_biomass_3=shoot_biomass_3/24.0
    
    root_biomass_1=root_biomass_1/24.0
    root_biomass_2=root_biomass_2/24.0
    root_biomass_3=root_biomass_3/24.0
    
    nitrogen_mass_1=nitrogen_mass_1/24.0
    nitrogen_mass_2=nitrogen_mass_2/24.0
    nitrogen_mass_3=nitrogen_mass_3/24.0
    
    leaf_area=leaf_area/24.0
    green_leaf_area=green_leaf_area/24.0
    
    shootbiomassLarc2011.append(shoot_biomass_1)
    shootbiomassLarc2011.append(shoot_biomass_2)
    shootbiomassLarc2011.append(shoot_biomass_3)
    
    rootbiomassLarc2011.append(root_biomass_1)
    rootbiomassLarc2011.append(root_biomass_2)
    rootbiomassLarc2011.append(root_biomass_3)
    
    nitrogenLarc2011.append(nitrogen_mass_1)
    nitrogenLarc2011.append(nitrogen_mass_2)
    nitrogenLarc2011.append(nitrogen_mass_3)
    
    leafareaLARC2011.append(leaf_area)
    leafareaLARC2011.append(green_leaf_area)
    
LARC2011ShootMassReshape=np.reshape(shootbiomassLarc2011, (15,3))
LARC2011RootMassReshape=np.reshape(rootbiomassLarc2011, (15,3))
LARC2011NitrogenMassReshape=np.reshape(nitrogenLarc2011, (15,3))
LARC2011LeafAreaReshape=np.reshape(leafareaLARC2011, (15,2))

LARC2011ALL=np.concatenate((LARC2011ShootMassReshape, LARC2011RootMassReshape, LARC2011NitrogenMassReshape), axis=0)

##############################################################################
shootbiomassCrsk2011=[]
rootbiomassCrsk2011=[]
nitrogenCrsk2011=[]
leafareaCrsk2011=[]
for trt in treatmentList_other:
    TargetDir=baseDir+siteList[4]+'\\'+trt+'\\'+siteList[4]+'.g01'
    df=pd.read_csv(TargetDir)
    df.set_index(['date','       time'], inplace=True)
    
    shoot_biomass_1=0.0
    shoot_biomass_2=0.0
    
    root_biomass_1=0.0
    root_biomass_2=0.0
    
    nitrogen_mass_1=0.0
    nitrogen_mass_2=0.0
    
    leaf_area=0.0
    green_leaf_area=0.0
    
    for iii in range(24):
        
        shoot_biomass_1=shoot_biomass_1+df.loc[('03/07/2012',iii)]['  ShootMass']*df.loc[('03/07/2012',iii)]['PltLivingFrac']*500.0
        shoot_biomass_2=shoot_biomass_2+df.loc[('05/09/2012',iii)]['  ShootMass']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0
        
        root_biomass_1=root_biomass_1+df.loc[('03/07/2012',iii)]['   RootMass']*df.loc[('03/07/2012',iii)]['PltLivingFrac']*500.0
        root_biomass_2=root_biomass_2+df.loc[('05/09/2012',iii)]['   RootMass']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0
    
        nitrogen_mass_1=nitrogen_mass_1+df.loc[('03/07/2012',iii)]['     NitroMass']*df.loc[('03/07/2012',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_2=nitrogen_mass_2+df.loc[('05/09/2012',iii)]['     NitroMass']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0
        
        leaf_area=leaf_area+df.loc[('05/09/2012',iii)]['   LeaveArea']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0/10000
        green_leaf_area=green_leaf_area+df.loc[('05/09/2012',iii)][' GreenLfArea']*df.loc[('05/09/2012',iii)]['PltLivingFrac']*500.0/10000
        
    shoot_biomass_1=shoot_biomass_1/24.0    
    shoot_biomass_2=shoot_biomass_2/24.0
    
    root_biomass_1=root_biomass_1/24.0
    root_biomass_2=root_biomass_2/24.0

    nitrogen_mass_1=nitrogen_mass_1/24.0
    nitrogen_mass_2=nitrogen_mass_2/24.0
    
    leaf_area=leaf_area/24.0
    green_leaf_area=green_leaf_area/24.0
    
    shootbiomassCrsk2011.append(shoot_biomass_1)
    shootbiomassCrsk2011.append(shoot_biomass_2)
    
    rootbiomassCrsk2011.append(root_biomass_1)
    rootbiomassCrsk2011.append(root_biomass_2)
    
    nitrogenCrsk2011.append(nitrogen_mass_1)
    nitrogenCrsk2011.append(nitrogen_mass_2)
    
    leafareaCrsk2011.append(leaf_area)
    leafareaCrsk2011.append(green_leaf_area)
    
CRSK2011ShootMassReshape=np.reshape(shootbiomassCrsk2011, (15,2))
CRSK2011RootMassReshape=np.reshape(rootbiomassCrsk2011, (15,2))
CRSK2011NitrogenMassReshape=np.reshape(nitrogenCrsk2011, (15,2))
CRSK2011LeafAreaReshape=np.reshape(leafareaCrsk2011, (15,2))

CRSK2011ALL=np.concatenate((CRSK2011ShootMassReshape, CRSK2011RootMassReshape, CRSK2011NitrogenMassReshape), axis=0)
  
##############################################################################  
shootbiomassPrss2011=[]
rootbiomassPrss2011=[]
nitrogenPrss2011=[]
leafareaPrss2011=[]
for trt in treatmentList_other:
    TargetDir=baseDir+siteList[5]+'\\'+trt+'\\'+siteList[5]+'.g01'
    df=pd.read_csv(TargetDir)
    df.set_index(['date','       time'], inplace=True)
    
    shoot_biomass_1=0.0
    shoot_biomass_2=0.0
    shoot_biomass_3=0.0
    
    root_biomass_1=0.0
    root_biomass_2=0.0
    root_biomass_3=0.0
    
    nitrogen_mass_1=0.0
    nitrogen_mass_2=0.0
    nitrogen_mass_3=0.0
    
    leaf_area=0.0
    green_leaf_area=0.0
    
    for iii in range(24):
        
        shoot_biomass_1=shoot_biomass_1+df.loc[('02/28/2012',iii)]['  ShootMass']*df.loc[('02/28/2012',iii)]['PltLivingFrac']*500.0
        shoot_biomass_2=shoot_biomass_2+df.loc[('03/19/2012',iii)]['  ShootMass']*df.loc[('03/19/2012',iii)]['PltLivingFrac']*500.0
        shoot_biomass_3=shoot_biomass_3+df.loc[('05/20/2012',iii)]['  ShootMass']*df.loc[('05/20/2012',iii)]['PltLivingFrac']*500.0
        
        root_biomass_1=root_biomass_1+df.loc[('02/28/2012',iii)]['   RootMass']*df.loc[('02/28/2012',iii)]['PltLivingFrac']*500.0
        root_biomass_2=root_biomass_2+df.loc[('03/19/2012',iii)]['   RootMass']*df.loc[('03/19/2012',iii)]['PltLivingFrac']*500.0
        root_biomass_3=root_biomass_3+df.loc[('05/20/2012',iii)]['   RootMass']*df.loc[('05/20/2012',iii)]['PltLivingFrac']*500.0
        
        nitrogen_mass_1=nitrogen_mass_1+df.loc[('02/28/2012',iii)]['     NitroMass']*df.loc[('02/28/2012',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_2=nitrogen_mass_2+df.loc[('03/19/2012',iii)]['     NitroMass']*df.loc[('03/19/2012',iii)]['PltLivingFrac']*500.0
        nitrogen_mass_3=nitrogen_mass_3+df.loc[('05/20/2012',iii)]['     NitroMass']*df.loc[('05/20/2012',iii)]['PltLivingFrac']*500.0
        
        leaf_area=leaf_area+df.loc[('05/20/2012',iii)]['   LeaveArea']*df.loc[('05/20/2012',iii)]['PltLivingFrac']*500.0/10000
        green_leaf_area=green_leaf_area+df.loc[('05/20/2012',iii)][' GreenLfArea']*df.loc[('05/20/2012',iii)]['PltLivingFrac']*500.0/10000
    
    shoot_biomass_1=shoot_biomass_1/24.0
    shoot_biomass_2=shoot_biomass_2/24.0
    shoot_biomass_3=shoot_biomass_3/24.0
    
    root_biomass_1=root_biomass_1/24.0
    root_biomass_2=root_biomass_2/24.0
    root_biomass_3=root_biomass_3/24.0
    
    nitrogen_mass_1=nitrogen_mass_1/24.0
    nitrogen_mass_2=nitrogen_mass_2/24.0
    nitrogen_mass_3=nitrogen_mass_3/24.0
    
    leaf_area=leaf_area/24.0
    green_leaf_area=green_leaf_area/24.0
    
    shootbiomassPrss2011.append(shoot_biomass_1)
    shootbiomassPrss2011.append(shoot_biomass_2)
    shootbiomassPrss2011.append(shoot_biomass_3)
    
    rootbiomassPrss2011.append(root_biomass_1)
    rootbiomassPrss2011.append(root_biomass_2)
    rootbiomassPrss2011.append(root_biomass_3)
    
    nitrogenPrss2011.append(nitrogen_mass_1)
    nitrogenPrss2011.append(nitrogen_mass_2)
    nitrogenPrss2011.append(nitrogen_mass_3)
    
    leafareaPrss2011.append(leaf_area)
    leafareaPrss2011.append(green_leaf_area)
    
PRSS2011ShootMassReshape=np.reshape(shootbiomassPrss2011, (15,3))
PRSS2011RootMassReshape=np.reshape(rootbiomassPrss2011, (15,3))
PRSS2011NitrogenMassReshape=np.reshape(nitrogenPrss2011, (15,3))
PRSS2011LeafAreaReshape=np.reshape(leafareaPrss2011, (15,2))

PRSS2011ALL=np.concatenate((PRSS2011ShootMassReshape, PRSS2011RootMassReshape, PRSS2011NitrogenMassReshape), axis=0)
    
shootbiomassTotal=shootbiomassBarc2010+shootbiomassBarc2011+shootbiomassLarc2011+shootbiomassCrsk2011+shootbiomassPrss2011
rootbiomassTotal=rootbiomassBarc2010+rootbiomassBarc2011+rootbiomassLarc2011+rootbiomassCrsk2011+rootbiomassPrss2011
nitrogenTotal=nitrogenBarc2010+nitrogenBarc2011+nitrogenLarc2011+nitrogenCrsk2011+nitrogenPrss2011
rootshootratio=np.divide(rootbiomassTotal,shootbiomassTotal)



FirstBiomassObs=np.concatenate((BARC2010ShootMassReshape[:,0],BARC2011ShootMassReshape[:,0],LARC2011ShootMassReshape[:,0],CRSK2011ShootMassReshape[:,0],PRSS2011ShootMassReshape[:,0]),axis=0)

# # supplement
# shootbiomassCrsk2011=[]
# rootbiomassCrsk2011=[]
# nitrogenCrsk2011=[]
# for trt in treatmentList_other:
#     TargetDir=baseDir+siteList[4]+'\\'+trt+'\\'+siteList[4]+'.g01'
#     df=pd.read_csv(TargetDir)
#     df.set_index(['date','       time'], inplace=True)
#     shoot_biomass=df.loc[('03/07/2012',0)]['  ShootMass']*df.loc[('03/07/2012',0)]['PltLivingFrac']*500.0
#     root_biomass=df.loc[('03/07/2012',0)]['   RootMass']*df.loc[('03/07/2012',0)]['PltLivingFrac']*500.0
#     nitrogen_mass=df.loc[('03/07/2012',0)]['     NitroMass']*df.loc[('03/07/2012',0)]['PltLivingFrac']*500.0
#     shootbiomassCrsk2011.append(shoot_biomass)
#     rootbiomassCrsk2011.append(root_biomass)
#     nitrogenCrsk2011.append(nitrogen_mass)
    
#     shoot_biomass=df.loc[('05/07/2012',0)]['  ShootMass']*df.loc[('05/07/2012',0)]['PltLivingFrac']*500.0
#     root_biomass=df.loc[('05/07/2012',0)]['   RootMass']*df.loc[('05/07/2012',0)]['PltLivingFrac']*500.0
#     nitrogen_mass=df.loc[('05/07/2012',0)]['     NitroMass']*df.loc[('05/07/2012',0)]['PltLivingFrac']*500.0
#     shootbiomassCrsk2011.append(shoot_biomass)
#     rootbiomassCrsk2011.append(root_biomass)
#     nitrogenCrsk2011.append(nitrogen_mass)