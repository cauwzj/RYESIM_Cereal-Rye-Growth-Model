# -*- coding: utf-8 -*-
"""
Created on Sun Apr 14 20:32:35 2024

@author: Zhuangji.Wang
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Apr 14 13:50:44 2024

@author: Zhuangji.Wang
"""

# biomass/N mass Summary
import pandas as pd
import numpy as np

baseDir = 'D:\\Ryesim\\CALIBRATION_EXAMPLE\\'
siteList=['BARC2010','BARC2011','LARC2011','CRSK2011','PRSS2011']
treatmentList=['N_00','N_01','N_02','N_10','N_11','N_12','N_20','N_21','N_22','N_30','N_31','N_32','N_50','N_51','N_52']


BiomassBarc2010=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[0]+'\\'+trt+'\\'+siteList[0]+'.g01'
    df=pd.read_csv(TargetDir)
    Biomass_number_1=np.array(np.multiply(df.loc[:,'  ShootMass'],df.loc[:,'PltLivingFrac'])*500.0)
    Biomass_number_1=np.reshape(Biomass_number_1,(Biomass_number_1.shape[0],1))
    i=i+1
    if (i==1):
        BiomassBarc2010=Biomass_number_1
    else:          
        BiomassBarc2010=np.append(BiomassBarc2010,Biomass_number_1,axis=0)

        
BiomassBarc2011=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[1]+'\\'+trt+'\\'+siteList[1]+'.g01'
    df=pd.read_csv(TargetDir)
    Biomass_number_1=np.array(np.multiply(df.loc[:,'  ShootMass'],df.loc[:,'PltLivingFrac'])*500.0)
    Biomass_number_1=np.reshape(Biomass_number_1,(Biomass_number_1.shape[0],1))
    i=i+1
    if (i==1):
        BiomassBarc2011=Biomass_number_1
    else:          
        BiomassBarc2011=np.append(BiomassBarc2011,Biomass_number_1,axis=0)


BiomassLarc2011=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[2]+'\\'+trt+'\\'+siteList[2]+'.g01'
    df=pd.read_csv(TargetDir)
    Biomass_number_1=np.array(np.multiply(df.loc[:,'  ShootMass'],df.loc[:,'PltLivingFrac'])*500.0)
    Biomass_number_1=np.reshape(Biomass_number_1,(Biomass_number_1.shape[0],1))
    i=i+1
    if (i==1):
        BiomassLarc2011=Biomass_number_1
    else:          
        BiomassLarc2011=np.append(BiomassLarc2011,Biomass_number_1,axis=0)

        
BiomassCrsk2011=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[3]+'\\'+trt+'\\'+siteList[3]+'.g01'
    df=pd.read_csv(TargetDir)
    Biomass_number_1=np.array(np.multiply(df.loc[:,'  ShootMass'],df.loc[:,'PltLivingFrac'])*500.0)
    Biomass_number_1=np.reshape(Biomass_number_1,(Biomass_number_1.shape[0],1))
    i=i+1
    if (i==1):
        BiomassCrsk2011=Biomass_number_1
    else:          
        BiomassCrsk2011=np.append(BiomassCrsk2011,Biomass_number_1,axis=0)

        
BiomassPrss2011=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[4]+'\\'+trt+'\\'+siteList[4]+'.g01'
    df=pd.read_csv(TargetDir)
    Biomass_number_1=np.array(np.multiply(df.loc[:,'  ShootMass'],df.loc[:,'PltLivingFrac'])*500.0)
    Biomass_number_1=np.reshape(Biomass_number_1,(Biomass_number_1.shape[0],1))
    i=i+1
    if (i==1):
        BiomassPrss2011=Biomass_number_1
    else:          
        BiomassPrss2011=np.append(BiomassPrss2011,Biomass_number_1,axis=0)

BiomassALL=np.concatenate((BiomassBarc2010,BiomassBarc2011,BiomassLarc2011,BiomassCrsk2011,BiomassPrss2011),axis=0)
       