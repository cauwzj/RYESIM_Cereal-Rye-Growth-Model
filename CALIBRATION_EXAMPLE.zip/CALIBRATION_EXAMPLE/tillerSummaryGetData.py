# -*- coding: utf-8 -*-
"""
Created on Sun Apr 14 13:50:44 2024

@author: Zhuangji.Wang
"""

# biomass/N mass Summary
import pandas as pd
import numpy as np

baseDir = 'D:\\Ryesim\\CALIBRATION_EXAMPLE\\'
siteList=['BARC2010','BARC2011','LARC2011','CRSK2011','PRSS2011']
treatmentList=['N_00','N_01','N_02','N_10','N_11','N_12','N_20','N_21','N_22','N_30','N_31','N_32','N_50','N_51','N_52']


tillerBarc2010=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[0]+'\\'+trt+'\\'+siteList[0]+'.g01'
    df=pd.read_csv(TargetDir)
    tiller_number_1=np.array(np.multiply(df.loc[:,'TillerNum'],df.loc[:,'PltLivingFrac'])*500.0)
    tiller_number_1=np.reshape(tiller_number_1,(tiller_number_1.shape[0],1))
    i=i+1
    if (i==1):
        tillerBarc2010=tiller_number_1
    else:          
        tillerBarc2010=np.append(tillerBarc2010,tiller_number_1,axis=0)

        
tillerBarc2011=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[1]+'\\'+trt+'\\'+siteList[1]+'.g01'
    df=pd.read_csv(TargetDir)
    tiller_number_1=np.array(np.multiply(df.loc[:,'TillerNum'],df.loc[:,'PltLivingFrac'])*500.0)
    tiller_number_1=np.reshape(tiller_number_1,(tiller_number_1.shape[0],1))
    i=i+1
    if (i==1):
        tillerBarc2011=tiller_number_1
    else:          
        tillerBarc2011=np.append(tillerBarc2011,tiller_number_1,axis=0)


tillerLarc2011=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[2]+'\\'+trt+'\\'+siteList[2]+'.g01'
    df=pd.read_csv(TargetDir)
    tiller_number_1=np.array(np.multiply(df.loc[:,'TillerNum'],df.loc[:,'PltLivingFrac'])*500.0)
    tiller_number_1=np.reshape(tiller_number_1,(tiller_number_1.shape[0],1))
    i=i+1
    if (i==1):
        tillerLarc2011=tiller_number_1
    else:          
        tillerLarc2011=np.append(tillerLarc2011,tiller_number_1,axis=0)

        
tillerCrsk2011=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[3]+'\\'+trt+'\\'+siteList[3]+'.g01'
    df=pd.read_csv(TargetDir)
    tiller_number_1=np.array(np.multiply(df.loc[:,'TillerNum'],df.loc[:,'PltLivingFrac'])*500.0)
    tiller_number_1=np.reshape(tiller_number_1,(tiller_number_1.shape[0],1))
    i=i+1
    if (i==1):
        tillerCrsk2011=tiller_number_1
    else:          
        tillerCrsk2011=np.append(tillerCrsk2011,tiller_number_1,axis=0)

        
tillerPrss2011=[]
i=0
for trt in treatmentList:
    TargetDir=baseDir+siteList[4]+'\\'+trt+'\\'+siteList[4]+'.g01'
    df=pd.read_csv(TargetDir)
    tiller_number_1=np.array(np.multiply(df.loc[:,'TillerNum'],df.loc[:,'PltLivingFrac'])*500.0)
    tiller_number_1=np.reshape(tiller_number_1,(tiller_number_1.shape[0],1))
    i=i+1
    if (i==1):
        tillerPrss2011=tiller_number_1
    else:          
        tillerPrss2011=np.append(tillerPrss2011,tiller_number_1,axis=0)  
        
tillerALL=np.concatenate((tillerBarc2010,tillerBarc2011,tillerLarc2011,tillerCrsk2011,tillerPrss2011),axis=0)
